// backend/server.js - Fixed Date Format Version
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// ✅ Serve static files (frontend)
app.use(express.static(path.join(__dirname, '../frontend')));

// ✅ Home route - serve frontend
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ✅ MySQL connection
const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "Sahanap@16",
  database: process.env.DB_NAME || "case_tracker"
});

db.connect(err => {
  if (err) {
    console.error("❌ Database connection failed:", err.message);
  } else {
    console.log("✅ Connected to MySQL Database");
    
    // Create table
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS cases (
        id VARCHAR(255) PRIMARY KEY,
        caseNumber VARCHAR(255) NOT NULL,
        courtName VARCHAR(255) NOT NULL,
        caseType VARCHAR(100) NOT NULL,
        fillingNumber VARCHAR(255),
        fillingDate DATE,
        registrationNumber VARCHAR(255),
        registrationDate DATE,
        partyName VARCHAR(255),
        caseFillingPartyName VARCHAR(255),
        caseStatus VARCHAR(100),
        firstHearingDate DATE,
        nextHearingDate DATE,
        createdAt DATETIME,
        updatedAt DATETIME
      )
    `;
    
    db.query(createTableQuery, (err) => {
      if (err) {
        console.error("❌ Table creation error:", err.message);
      } else {
        console.log("✅ Cases table ready");
      }
    });
  }
});

// ✅ Helper function to format dates for MySQL
function formatDateForMySQL(dateString) {
  if (!dateString) return null;
  // If it's already in YYYY-MM-DD format, return as is
  if (typeof dateString === 'string' && dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
    return dateString;
  }
  // If it's an ISO string, extract YYYY-MM-DD
  if (typeof dateString === 'string' && dateString.includes('T')) {
    return dateString.split('T')[0];
  }
  return null;
}

// ✅ List all cases
app.get("/cases", (req, res) => {
  console.log("📥 GET /cases request received");
  const sql = "SELECT * FROM cases ORDER BY createdAt DESC";
  db.query(sql, (err, results) => {
    if (err) {
      console.error("❌ SQL Error:", err.message);
      return res.status(500).json({ error: err.message });
    }
    console.log(`✅ Sent ${results.length} cases`);
    res.json(results);
  });
});

// ✅ Add a new case - FIXED DATE FORMAT
app.post("/cases", (req, res) => {
  console.log("📥 POST /cases request received", req.body);
  
  const caseData = req.body;
  
  // ✅ FIX: Format dates properly for MySQL
  const now = new Date();
  caseData.createdAt = now.toISOString().slice(0, 19).replace('T', ' '); // '2024-01-01 12:00:00'
  caseData.updatedAt = now.toISOString().slice(0, 19).replace('T', ' ');
  
  // ✅ FIX: Format date fields
  caseData.fillingDate = formatDateForMySQL(caseData.fillingDate);
  caseData.registrationDate = formatDateForMySQL(caseData.registrationDate);
  caseData.firstHearingDate = formatDateForMySQL(caseData.firstHearingDate);
  caseData.nextHearingDate = formatDateForMySQL(caseData.nextHearingDate);
  
  console.log("📅 Formatted case data:", caseData);
  
  const sql = "INSERT INTO cases SET ?";
  db.query(sql, caseData, (err, result) => {
    if (err) {
      console.error("❌ Database Insert Error:", err.message);
      console.error("❌ Full error details:", err);
      return res.status(500).json({ error: err.message });
    }
    console.log("✅ Case added to database, ID:", caseData.id);
    res.json({ 
      message: "Case added successfully",
      id: caseData.id 
    });
  });
});

// ✅ Update existing case - FIXED DATE FORMAT
app.put("/cases/:id", (req, res) => {
  const { id } = req.params;
  console.log(`📥 PUT /cases/${id} request received`);
  
  const updatedCaseData = req.body;
  
  // ✅ FIX: Format dates properly for MySQL
  updatedCaseData.updatedAt = new Date().toISOString().slice(0, 19).replace('T', ' ');
  
  // ✅ FIX: Format date fields
  updatedCaseData.fillingDate = formatDateForMySQL(updatedCaseData.fillingDate);
  updatedCaseData.registrationDate = formatDateForMySQL(updatedCaseData.registrationDate);
  updatedCaseData.firstHearingDate = formatDateForMySQL(updatedCaseData.firstHearingDate);
  updatedCaseData.nextHearingDate = formatDateForMySQL(updatedCaseData.nextHearingDate);
  
  const sql = "UPDATE cases SET ? WHERE id = ?";
  db.query(sql, [updatedCaseData, id], (err, result) => {
    if (err) {
      console.error("❌ Update Error:", err.message);
      return res.status(500).json({ error: err.message });
    }
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Case not found" });
    }
    
    console.log("✅ Case updated successfully");
    res.json({ message: "Case updated successfully" });
  });
});

// ✅ Delete case
app.delete("/cases/:id", (req, res) => {
  const { id } = req.params;
  console.log(`📥 DELETE /cases/${id} request received`);
  
  const sql = "DELETE FROM cases WHERE id = ?";
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("❌ Delete Error:", err.message);
      return res.status(500).json({ error: err.message });
    }
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Case not found" });
    }
    
    console.log("✅ Case deleted successfully");
    res.json({ message: "Case deleted successfully" });
  });
});

// ✅ Handle all other routes by serving index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ✅ Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});