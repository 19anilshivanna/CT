// app.js - Case Tracker with MySQL Backend

class CaseTracker {
  constructor() {
    this.apiBase = "http://localhost:5000"; 
    this.cases = [];
    this.editingCaseId = null;
    this.init();
  }

  async init() {
    this.setupEventListeners();
    await this.loadCases();
  }

  setupEventListeners() {
    document.getElementById("caseForm").addEventListener("submit", async e => {
      e.preventDefault();
      if (this.editingCaseId) {
        await this.updateCase(this.editingCaseId);
      } else {
        await this.addCase();
      }
    });

    document.getElementById("searchInput").addEventListener("input", e => {
      this.searchCases(e.target.value);
    });

    document.getElementById("casesList").addEventListener("click", e => {
      const caseItem = e.target.closest(".case-item");
      if (!caseItem) return;

      const caseId = caseItem.getAttribute("data-case-id");
      if (e.target.classList.contains("btn-view")) this.viewCase(caseId);
      if (e.target.classList.contains("btn-edit")) this.editCase(caseId);
      if (e.target.classList.contains("btn-delete")) this.deleteCase(caseId);
    });
  }

  async addCase() {
    const caseData = this.collectFormData();
    if (!this.validateCase(caseData)) return;

    caseData.id = this.generateId();
    caseData.createdAt = new Date();
    caseData.updatedAt = new Date();

    await fetch(`${this.apiBase}/cases`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(caseData)
    });

    await this.loadCases();
    this.resetForm();
    this.showNotification("Case added successfully", "success");
  }

  async updateCase(id) {
    const updatedCaseData = this.collectFormData();
    if (!this.validateCase(updatedCaseData)) return;

    updatedCaseData.updatedAt = new Date();

    await fetch(`${this.apiBase}/cases/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedCaseData)
    });

    await this.loadCases();
    this.resetForm();
    this.showNotification("Case updated successfully", "success");
  }

  async deleteCase(id) {
    if (!confirm("Delete this case?")) return;
    await fetch(`${this.apiBase}/cases/${id}`, { method: "DELETE" });
    await this.loadCases();
    this.showNotification("Case deleted", "success");
  }

  async loadCases() {
    const response = await fetch(`${this.apiBase}/cases`);
    this.cases = await response.json();
    this.displayCases(this.cases);
  }

  collectFormData() {
    return {
      caseNumber: document.getElementById("caseNumber").value.trim(),
      courtName: document.getElementById("courtName").value.trim(),
      caseType: document.getElementById("caseType").value,
      fillingNumber: document.getElementById("fillingNumber").value.trim(),
      fillingDate: document.getElementById("fillingDate").value,
      registrationNumber: document.getElementById("registrationNumber").value.trim(),
      registrationDate: document.getElementById("registrationDate").value,
      partyName: document.getElementById("partyName").value.trim(),
      caseFillingPartyName: document.getElementById("caseFillingPartyName").value.trim(),
      caseStatus: document.getElementById("caseStatus").value,
      firstHearingDate: document.getElementById("firstHearingDate").value,
      nextHearingDate: document.getElementById("nextHearingDate").value
    };
  }

  validateCase(caseData) {
    if (!caseData.caseNumber || !caseData.courtName || !caseData.caseType) {
      this.showNotification("Please fill all required fields", "error");
      return false;
    }
    return true;
  }

  resetForm() {
    document.getElementById("caseForm").reset();
    this.editingCaseId = null;
  }

  displayCases(cases) {
    const list = document.getElementById("casesList");
    list.innerHTML = "";
    if (cases.length === 0) {
      list.innerHTML = `<p>No cases found</p>`;
      return;
    }

    cases.forEach(c => {
      const div = document.createElement("div");
      div.classList.add("case-item");
      div.setAttribute("data-case-id", c.id);
      div.innerHTML = `
        <h3>${c.caseNumber}</h3>
        <p>${c.courtName} — ${c.caseType}</p>
        <p>Status: ${c.caseStatus}</p>
        <button class="btn-view">View</button>
        <button class="btn-edit">Edit</button>
        <button class="btn-delete">Delete</button>
      `;
      list.appendChild(div);
    });
  }

  searchCases(query) {
    const filtered = this.cases.filter(c =>
      c.caseNumber.toLowerCase().includes(query.toLowerCase())
    );
    this.displayCases(filtered);
  }

  generateId() {
    return "case_" + Date.now().toString(36);
  }

  showNotification(msg, type = "info") {
    alert(`${type.toUpperCase()}: ${msg}`);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  window.caseTracker = new CaseTracker();
});
